var searchData=
[
  ['resource_20lists',['Resource lists',['../group__rlists.html',1,'']]]
];
