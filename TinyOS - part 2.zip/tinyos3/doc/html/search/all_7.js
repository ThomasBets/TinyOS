var searchData=
[
  ['get_5fcore_5fpreemption',['get_core_preemption',['../kernel__cc_8c.html#ac3fd575c0f82fd75f8e7305be1107e2c',1,'get_core_preemption():&#160;kernel_cc.c'],['../kernel__cc_8h.html#ac3fd575c0f82fd75f8e7305be1107e2c',1,'get_core_preemption():&#160;kernel_cc.c']]],
  ['get_5ffcb',['get_fcb',['../group__streams.html#ga36b4f172aba29ba2660d0aed0f10d60b',1,'get_fcb(Fid_t fid):&#160;kernel_streams.c'],['../group__streams.html#ga36b4f172aba29ba2660d0aed0f10d60b',1,'get_fcb(Fid_t fid):&#160;kernel_streams.c']]],
  ['get_5fpcb',['get_pcb',['../group__proc.html#ga10cf45ea8bc92b00bd1f25553b9cf5c8',1,'get_pcb(Pid_t pid):&#160;kernel_proc.c'],['../group__proc.html#ga10cf45ea8bc92b00bd1f25553b9cf5c8',1,'get_pcb(Pid_t pid):&#160;kernel_proc.c']]],
  ['get_5fpid',['get_pid',['../group__proc.html#ga110e884cb053244b18d1058751a78cfe',1,'get_pid(PCB *pcb):&#160;kernel_proc.c'],['../group__proc.html#ga110e884cb053244b18d1058751a78cfe',1,'get_pid(PCB *pcb):&#160;kernel_proc.c']]],
  ['getpid',['GetPid',['../group__syscalls.html#ga5106ac1f078c5dde2d6fea3881c1a4fb',1,'tinyos.h']]],
  ['getppid',['GetPPid',['../group__syscalls.html#ga33ccb3f7c80d85e610206c0e1150657b',1,'tinyos.h']]],
  ['getterminaldevices',['GetTerminalDevices',['../group__syscalls.html#ga31576e1579c15b6b066038702e6557c7',1,'tinyos.h']]]
];
