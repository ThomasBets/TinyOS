var searchData=
[
  ['ctx_5fclean',['CTX_CLEAN',['../group__scheduler.html#ggab180b4aa356776bddcd724cef4f5deaeaa826daca588e692c88114586b0de472b',1,'kernel_sched.h']]],
  ['ctx_5fdirty',['CTX_DIRTY',['../group__scheduler.html#ggab180b4aa356776bddcd724cef4f5deaea2b4b41fda67c1a83e6523675515c007b',1,'kernel_sched.h']]]
];
