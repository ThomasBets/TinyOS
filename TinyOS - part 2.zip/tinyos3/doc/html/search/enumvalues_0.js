var searchData=
[
  ['alarm',['ALARM',['../bios_8h.html#a137af7bce5ff764f5c0aa4550086deaaac4212312865bd8ac6810b9651d9e80df',1,'bios.h']]],
  ['alive',['ALIVE',['../group__proc.html#gga4f133ac5f9b2ca9c1446889baee1dc05a4f34c5c191d6e0d028ca831b6c0b1571',1,'kernel_proc.h']]]
];
