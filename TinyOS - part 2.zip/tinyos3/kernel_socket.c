#include "tinyos.h"
#include "kernel_dev.h"
#include "kernel_sched.h"
#include "kernel_streams.h"
#include "kernel_cc.h"
Socket_CB* PORT_MAP[MAX_PORT+1]={NULL};


/************************CREATE SOCKET AND FILE OPTIONS**********/


int socket_read(void* this, char *buf, unsigned int size){
	Socket_CB* socketcb= (Socket_CB*) this;
	Pipe_CB* pipe;
	pipe=socketcb->peer->receiver;

	return pipe_read(pipe,buf,size);
}

int socket_write(void* this, const char *buf, unsigned int size){
	Socket_CB* socketcb= (Socket_CB*) this;
	Pipe_CB* pipe;
	pipe=socketcb->peer->sender;

	return pipe_write(pipe,buf,size);
}

int socket_not_write(void* k,const  char * buf, unsigned int size){
  return -1;
}

int socket_not_read(void* k, char * buf, unsigned int size){
  
  return -1;
}


int socket_close(void* this){
	
	int ret=-1;
	Socket_CB* socketcb= (Socket_CB*) this;
	if(this){

		if(socketcb->type==LISTENER){
			kernel_broadcast(&socketcb->listener->req_available);
		}
		free(socketcb);
	    ret = 0;
	}else{
		ret=-1;
	}
return ret;
}

static file_ops socket_fops = {
	.Read=socket_not_read,
	.Write=socket_not_write,
	.Close=socket_close
};

static file_ops peer_socket_fops={
	.Read=socket_read,
	.Write=socket_write,
	.Close=socket_close
};


/************************INITIALIZES*******************/

Socket_CB* create_SocketCB(port_t port, FCB* fcb, socket_type type){

		Socket_CB* socketcb=(Socket_CB*) xmalloc(sizeof(Socket_CB));
		socketcb->port=port;
		socketcb->fcb=fcb;
		socketcb->type=type;
                socketcb->socket_fops=socket_fops;
	        return socketcb;
}

Listener_Socket* initialize_ListenerSocketCB(){

		
		Listener_Socket* listener=(Listener_Socket*) xmalloc(sizeof(Listener_Socket));
		listener->req_available=COND_INIT;
		rlnode_init(&listener->queue,NULL);

		return listener;
}

req_node* initialize_req_node(Socket_CB* socketcb){
		req_node* request=(req_node*)xmalloc(sizeof(req_node));
		request->socketcb=socketcb;
		rlnode_init(&request->node, request->socketcb->fcb);
		request->req_cv=COND_INIT;
		request->flag=0;

		return request;
}

Peer_Socket* initialize_PeerSocket(Socket_CB* other_peer, Pipe_CB* send, Pipe_CB* receive){
		Peer_Socket* peer=(Peer_Socket*)xmalloc(sizeof(Peer_Socket));
		peer->other_socket=other_peer;
		peer->sender=send;
		peer->receiver=receive;

		return peer;
}

/*****************SYSTEM CALLS************************/


Fid_t sys_Socket(port_t port)
{
	FCB* fcb;
	Fid_t fid;
	Socket_CB* socketcb;
	Fid_t return_temp ;
	if(FCB_reserve(1, &fid, &fcb)==0 ){
		return_temp=NOFILE;
	}else{
		if(port<=MAX_PORT && port>=0){
			socketcb=create_SocketCB(port,fcb,UNBOUND);
			fcb->streamobj=socketcb;
			fcb->streamfunc=&socket_fops;
			return_temp=fid;
			
			if (PORT_MAP[port]==NULL || PORT_MAP[port]->type!=LISTENER){//elegxei an yparxei allos listener				
				PORT_MAP[port]=socketcb;
			}
		}else{
			
			FCB_unreserve(1, &fid, &fcb); //release a fcb
			return_temp=NOFILE;
		}
		
	}
	return return_temp;
}

Socket_CB* get_socketCB(Fid_t fid){

	Socket_CB* socketcb;
	FCB* fcb = get_fcb(fid);

	if(fcb==NULL){ 
	return NULL;
	}
	return  socketcb=fcb->streamobj;
}

int sys_Listen(Fid_t sock)
{
	int return_temp=0;
	Socket_CB* socketcb=get_socketCB(sock);
	//socketcb=create_SocketCB(socketcb->port,socketcb->fcb,UNBOUND);
	//assert(socketcb==NULL);
	//assert(socketcb->type!=LISTENER);
	//assert(PORT_MAP[socketcb->port]!=NULL);
	//assert(PORT_MAP[socketcb->port]->type!=LISTENER);
	if(socketcb!=NULL && socketcb->type==UNBOUND && socketcb->port>0 && socketcb->port<MAX_PORT && PORT_MAP[socketcb->port]->type!=LISTENER ){
		
		socketcb->listener=initialize_ListenerSocketCB();
	        socketcb->type=LISTENER;
	}else{
		    return_temp=-1;
	}
	//("LISTEN OK \n");printf
	return return_temp;
}


Fid_t sys_Accept(Fid_t lsock)
{
        Socket_CB* listener_socket;
	Socket_CB* socket_to_connect;
	Socket_CB* server;
	pipe_t p1;
	pipe_t p2;
	Pipe_CB* pipe1;
	Pipe_CB* pipe2;
	Fid_t server_fid;
	rlnode* mynode=NULL;
	int success1,success2 =0;
	int ret=0;

	listener_socket=get_socketCB(lsock);

	if(listener_socket!=NULL ){

		if(listener_socket->type==LISTENER){

			
			while(is_rlist_empty(&listener_socket->listener->queue) && get_socketCB(lsock)!=NULL){
				kernel_wait(& listener_socket->listener->req_available,SCHED_USER);

			}
			if(listener_socket==get_socketCB(lsock)){
                              	server=(Socket_CB*)xmalloc(sizeof(Socket_CB));
				//ftiaxnw temp rlnode gia na perasw auto pou tha bgalw apo to queue tou listener
				mynode=(rlnode*)xmalloc(sizeof(rlnode));
				//to bazw sto mynode auto pou ebgala tipou rlnode
				mynode=rlist_pop_front( &listener_socket->listener->queue )->node;
				//bazw sto queue tou listener tou get_socketCB(server_fid);socket to connect ton kombo pou ebgala apo ton listener
				//etsi deixnw oti to sigkekrimeno socket exei enan listener pou mesa sto queue exei ta stoixeia tou 
				//rlist_push_front(&socket_to_connect->listener->queue, rlist_pop_front( &listener_socket->listener->queue )->node);
                               socket_to_connect=create_SocketCB(listener_socket->port, mynode->fcb, PEER);
				
				//CREATE THE NEW SOCKET --> SERVER
				server_fid=sys_Socket(listener_socket->port);
 				//FCB_reserve(1, &server_fid, &server_fcb);
				// server=create_SocketCB(listener_socket->port,server_fcb, UNBOUND);

				server=get_socketCB(server_fid);
				//server=create_SocketCB(listener_socket->port, mynode->fcb, PEER);
                                assert(server!=NULL);
				socket_to_connect->type=PEER;
				server->type=PEER;
				socket_to_connect->socket_fops=peer_socket_fops;
				server->socket_fops=peer_socket_fops;

				success1=sys_Pipe(&p1);
				success2=sys_Pipe(&p2);
				
				if(success1==0 && success2==0){

					pipe1= get_fcb(p1.read)->streamobj;
					pipe2= get_fcb(p2.read)->streamobj;
					
					//p1: server-->client    p2: client -->server 
					socket_to_connect->peer=initialize_PeerSocket(server,pipe2,pipe1);
					server->peer=initialize_PeerSocket(socket_to_connect,pipe1,pipe2);

					socket_to_connect->flag=1;
					//kernel_broadcast(&mynode->req_cv);
					ret=server_fid;
			

				}else{
					fprintf(stderr, "ERROR ! NO PIPES\n");
					ret=-1;
				}
			}else{
				ret=-1;
			}
		}else{
			ret=-1;
		}
	}else{
		ret=-1;
	}

	return ret;
}

int sys_Connect(Fid_t sock, port_t port, timeout_t timeout)
{
        int return_temp=0;
	Socket_CB* socket_to_connect;
	Socket_CB* listener;
	req_node* node;

	if (get_fcb(sock) == NULL || sock < 0 || sock > MAX_FILEID){
        	return -1;
    	}

	socket_to_connect=get_socketCB(sock);

	//if(socket_to_connect->type!=PEER) return_temp=-1;

	if(socket_to_connect!=NULL && socket_to_connect->type==UNBOUND && port<=MAX_PORT && port>0 && PORT_MAP[port]!=NULL){
		node=initialize_req_node(socket_to_connect);
		
		if(PORT_MAP[port]->type==LISTENER){

			listener=PORT_MAP[port]->fcb->streamobj;

			rlist_push_back(&listener->listener->queue, &node->node);

			kernel_broadcast(&listener->listener->req_available);

			kernel_timedwait(&node->req_cv,SCHED_USER,timeout);
		
		}else{
			fprintf(stderr, "ERROR NO LISTENER\n");
			
			return_temp=-1;
		}
		
	}else{
		return_temp=-1;
	}
	//printf("\n metabliti : %d \n",return_temp);
	return return_temp;
}


int sys_ShutDown(Fid_t sock, shutdown_mode how)
{
	int ret=0;
	Socket_CB* socketcb;
	socketcb=get_socketCB(sock);
	if(socketcb!=NULL && socketcb->type==PEER){
		if(how==SHUTDOWN_READ){
			pipe_reader_close(socketcb->peer->receiver);
		}else if(how ==SHUTDOWN_WRITE){
			pipe_writer_close(socketcb->peer->sender);
		}else if(how==SHUTDOWN_BOTH){
			pipe_reader_close(socketcb->peer->receiver);
			pipe_writer_close(socketcb->peer->sender);
		}
                 else {
                      socket_close(socketcb->peer->other_socket);
                }
		socket_close(socketcb);
	    
	}else{
		ret=-1;
	}

	return ret;
}

