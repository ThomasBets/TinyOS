#include "tinyos.h"
#include "kernel_dev.h"
#include "kernel_streams.h"
#include "kernel_cc.h"

/*-------------READER----------------*/
int pipe_read(void * this, char *buf, unsigned int size) {
    
    unsigned int read_size;//to megethos toy buffer poy stelnoyme pisw ston user
    unsigned int max_size;
    Pipe_CB *pipecb = (Pipe_CB *) this;

    while(pipecb->size == 0 && pipecb->writer!=NULL) {
	kernel_signal(&pipecb->buffer_empty);
        kernel_wait(&pipecb->buffer_full, SCHED_USER);
    }

    if (pipecb->start >= pipecb->end){
        max_size = PIPE_BUFF_SIZE - pipecb->start + pipecb->end;
    }else{
        max_size = pipecb->end - pipecb->start;
    }

    if (size > PIPE_BUFF_SIZE){
        read_size = PIPE_BUFF_SIZE;
    }else{
        read_size = size;
    }

    if (read_size > max_size) {
        read_size = max_size;
    }

    if (pipecb->size == 0 && pipecb->writer==NULL) {//EOF
        return 0;
    }

    for (int i = 0; i < read_size; i++) {
        buf[i] = pipecb->buffer[(pipecb->start + i) % PIPE_BUFF_SIZE];
    }

    pipecb->start = (pipecb->start + read_size) % PIPE_BUFF_SIZE;
    pipecb->size = pipecb->size - read_size;
    kernel_signal(&pipecb->buffer_empty);

    return read_size;
}


int pipe_reader_close(void * this ){
    Pipe_CB *pipecb = (Pipe_CB *)this;
    pipecb->reader=NULL;
    return 0;
}


/*-------------WRITER-----------------*/

int pipe_write(void * k, const char *buf, unsigned int size) {
    
    unsigned int read_size;
    unsigned int max_size;
    Pipe_CB *pipecb= (Pipe_CB *)k;

    if(pipecb->reader==NULL) { 
        return -1;
    }

    if (pipecb->start > pipecb->end){
        max_size = pipecb->start - pipecb->end;
    }else{
        max_size = PIPE_BUFF_SIZE - pipecb->end + pipecb->start;
    }

    if (size > PIPE_BUFF_SIZE) {
        read_size = PIPE_BUFF_SIZE; 
    }
    else {
        read_size = size;
    }

    if (read_size > max_size) { ///koimizw
        
	read_size = max_size;
        kernel_signal(&pipecb->buffer_full);
	kernel_wait(&pipecb->buffer_empty, SCHED_USER);
    }

    for (int i = 0; i < read_size; i++) {
        pipecb->buffer[(pipecb->end+i)% PIPE_BUFF_SIZE]=buf[i];
    }

    pipecb->end = (pipecb->end + read_size) % PIPE_BUFF_SIZE;
    pipecb->size = pipecb->size + read_size;
    kernel_signal(&pipecb->buffer_full);

    return read_size;
}

int pipe_writer_close(void * k ){
    Pipe_CB *pipecb = (Pipe_CB *)k;
    pipecb->writer=NULL;

    return 0;
}


/*--------------OPERATIONS-------------*/

int pipe_not_read(void * k, char *buf, unsigned int size){
    return -1;}

int pipe_not_write(void * l,const char *buf, unsigned int size){
    return -1;}

static file_ops read_ops={
        .Read=pipe_read,  
        .Write=pipe_not_write,
        .Close=pipe_reader_close
};

static file_ops write_ops={
        .Read=pipe_not_read,  
        .Write=pipe_write,
        .Close=pipe_writer_close
};


/***********************************

  The pipe control block (initialize & func)

***********************************/

Pipe_CB* pipeCB_initialiaze(FCB *reader1, FCB* writer1)
{
    Pipe_CB *pipecb=(Pipe_CB *)xmalloc(sizeof(Pipe_CB));
    pipecb->buffer_full=COND_INIT;
    pipecb->buffer_empty=COND_INIT;
    pipecb->start=0;
    pipecb->end=0;
    reader1->streamobj=pipecb;
    writer1->streamobj=pipecb;
    pipecb->reader=reader1;
    pipecb->writer=writer1;

    return pipecb;

}


int sys_Pipe(pipe_t* pipe)
{
    FCB * fcb_array[2];
    Fid_t fid[2];
    int flag;

    if(FCB_reserve(2,fid,fcb_array)==0){
            flag=-1;
    }  
    else {
            pipeCB_initialiaze(fcb_array[0],fcb_array[1]);
            pipe->read=fid[0];
            pipe->write=fid[1];
            fcb_array[0]->streamfunc=&read_ops;
            fcb_array[1]->streamfunc=&write_ops;
            flag=0;
    } 
    return flag;
}

