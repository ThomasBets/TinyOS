
#include "tinyos.h"
#include "kernel_sched.h"
#include "kernel_proc.h"
#include "kernel_cc.h"


// initialization of ptcb
PTCB* initialize_PTCB(TCB* tcb)
{
  PTCB* ptcb = (PTCB*) xmalloc(sizeof(PTCB)); //dynamically allocate ptcb cells
  ptcb->ref_count =0;  
  ptcb->argl = 0;
  ptcb->args = NULL;
  ptcb->exited=0; 
  ptcb->detached=0;
  ptcb->exit_cv = COND_INIT; 
  ptcb->tcb=tcb;
  tcb->owner_ptcb=ptcb;		//set that ptcb as the ptcb owner of the tcb
  rlnode_init(& ptcb->thread_list_node, ptcb);
  
  return ptcb; 
}


void PTCB_release(PTCB* ptcb){

  rlist_remove(&ptcb->thread_list_node);
  CURPROC->thread_count--; //decrease number of threads
  free(ptcb);
}


/*
A function that set values for task argl args and exitval*/
void start_new_thread()
{
  int exitval;

  Task task =  CURTHREAD->owner_ptcb->task;
  int argl = CURTHREAD->owner_ptcb->argl;
  void* args = CURTHREAD->owner_ptcb->args;

  exitval = task(argl,args);
  ThreadExit(exitval);
}

/*
In this function we create ptcb 
Call spawn thread with function "start new thread"
set tcb->pcb
Initialize PTCB of this tcb
and push pack at the list
*/
PTCB* PTCB_create(Task task, int argl, void* args,void (*func)(),PCB* pcb)
{ 
   TCB* tcb;
   PTCB* ptcb;
   if(task != NULL) { 
     tcb= spawn_thread(func,pcb);
     tcb->owner_pcb=pcb;
   }
   ptcb=initialize_PTCB(tcb);
   rlist_push_back( &pcb->thread_list, & ptcb->thread_list_node); ////////////CHANGED CURPOC TO PCB->
   ptcb->task=task;
   ptcb->argl = argl;
   ptcb->args = args;

  return ptcb;
}

/** 
  @brief Create a new thread in the current process.
  Call PTCB_create with task, argl, args start_new_thread and Current Proccess
  Increase thread count = how many thread we have
  Wake up the thread
  Return the ptcb (as told in the class for debugging reasons)
  */
Tid_t sys_CreateThread(Task task, int argl, void* args)
{

  PTCB* ptcb;
  ptcb=PTCB_create(task,argl,args,start_new_thread,CURPROC);
  CURPROC->thread_count++;
  wakeup(ptcb->tcb);
	return (Tid_t)ptcb; 

}

/**
  @brief Return the Tid of the current thread.
 */
Tid_t sys_ThreadSelf()
{
	return (Tid_t) CURTHREAD->owner_ptcb;
}

/**
  @brief Join the given thread.
  Return 0 if the thread is 
  	1) DETATCHED
  	2) the SAME THREAD or 
  	3) EXITED
  */
int sys_ThreadJoin(Tid_t tid, int* exitval)
{
	int return_val=0;
  PTCB* ptcb=(PTCB*) tid;  
  if (ptcb->detached==1 || (Tid_t)ptcb==sys_ThreadSelf() || ptcb->exited==1 ){
    return_val=-1;
  }
  else
  { 
      ptcb->ref_count++;
          
    while (ptcb->exited==0 && ptcb->detached==0){
      kernel_wait(& ptcb->exit_cv,SCHED_USER);
      }
      ptcb->ref_count--;

    if(ptcb->exited==1) 
    {
        if(exitval != NULL){  //Check if there is thread
            (*exitval)=ptcb->exitval;
        }
          
        if(ptcb->ref_count==0){
          PTCB_release(ptcb);
        }

        return_val=0;

    } 
    else {return_val= -1;}
  }
   return return_val;
}     

/**
  @brief Detach the given thread.
  0->not detatched
  1->detatched

  Returns:	--  0 on success
  			-- -1 on error
  */
int sys_ThreadDetach(Tid_t tid)
{
  int return_val=0;
  PTCB* ptcb=(PTCB*)tid;
  if (ptcb->exited==1 || ptcb==NULL ){	//Check: if PTCB is exited or null return -1
    return_val=-1;
  }else{
    if (ptcb->ref_count >1 && ptcb->detached==0){	//if not detached we do it
      kernel_broadcast(& ptcb->exit_cv);   //wake up the thread that join this thread
      return_val=0; 
    }
  }
  if(return_val==0){
    ptcb->detached=1;  //detatched!
  }
  return return_val;
}

/**
  @brief Terminate the current thread.
  Make PTCB extied
  */
void sys_ThreadExit(int exitval)
{
  PTCB* ptcb=(PTCB*)sys_ThreadSelf(); 
  ptcb->exited=1;
  kernel_broadcast(&ptcb->exit_cv);

  kernel_sleep(EXITED, SCHED_USER);

}

