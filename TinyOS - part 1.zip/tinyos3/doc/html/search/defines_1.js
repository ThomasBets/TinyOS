var searchData=
[
  ['max_5fcores',['MAX_CORES',['../bios_8h.html#a009855593b59738d24dbfc236edb3b14',1,'bios.h']]],
  ['max_5fterminals',['MAX_TERMINALS',['../bios_8h.html#a4e7d162c7c35103b42768ff4a5c73905',1,'bios.h']]]
];
