var searchData=
[
  ['concurrency_20control_2e',['Concurrency control.',['../group__cc.html',1,'']]]
];
